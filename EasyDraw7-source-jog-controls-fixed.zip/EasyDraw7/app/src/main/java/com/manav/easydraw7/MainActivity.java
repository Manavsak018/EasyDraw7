package com.manav.easydraw7;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION = "com.manav.easydraw7.USB_PERMISSION";
    private UsbManager usbManager;
    private TextView usbStatus;
    private DrawingView drawingView;
    private UsbDevice selectedDevice;
    private UsbDeviceConnection usbConnection;
    private EbbPlotter plotter;
    private boolean receiverRegistered = false;
    private boolean plotPaused = false;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (this) {
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && device != null) {
                        connectDevice(device);
                    } else setStatus("USB detected · permission not granted", false);
                }
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
                scanUsbDevices();
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (selectedDevice != null && device != null && selectedDevice.getDeviceId() == device.getDeviceId()) {
                    closeConnection(); setStatus("Plotter disconnected", false);
                }
                scanUsbDevices();
            }
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(245,247,250));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        usbManager = (UsbManager)getSystemService(Context.USB_SERVICE);
        registerUsbReceiver();
        buildInterface();
        scanUsbDevices();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button button(String value) {
        Button b = new Button(this); b.setText(value); b.setTextSize(13); b.setAllCaps(false); return b;
    }
    private void buildInterface() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,247,250));
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(16),dp(12),dp(16),dp(12)); header.setBackgroundColor(Color.WHITE);
        LinearLayout titleBox = new LinearLayout(this); titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.addView(text("EasyDraw 7",22,Color.rgb(25,39,62)));
        titleBox.addView(text("MakerQ EasyDraw V3 · USB plotter",12,Color.GRAY));
        header.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));
        Button scan = button("Scan USB"); scan.setOnClickListener(v -> scanUsbDevices()); header.addView(scan);
        root.addView(header);

        usbStatus = text("Checking USB devices…",13,Color.rgb(65,75,90)); usbStatus.setPadding(dp(16),dp(12),dp(16),dp(12)); usbStatus.setBackgroundColor(Color.rgb(232,241,250)); root.addView(usbStatus);

        LinearLayout tools = new LinearLayout(this); tools.setGravity(Gravity.CENTER_VERTICAL); tools.setPadding(dp(6),dp(5),dp(6),dp(5)); tools.setBackgroundColor(Color.WHITE);
        Button pen=button("Draw"), erase=button("Erase"), clear=button("Clear"), addText=button("Text"), addImage=button("Image");
        tools.addView(pen,new LinearLayout.LayoutParams(0,-2,1)); tools.addView(erase,new LinearLayout.LayoutParams(0,-2,1)); tools.addView(clear,new LinearLayout.LayoutParams(0,-2,1)); tools.addView(addText,new LinearLayout.LayoutParams(0,-2,1)); tools.addView(addImage,new LinearLayout.LayoutParams(0,-2,1)); root.addView(tools);

        drawingView = new DrawingView(this); LinearLayout.LayoutParams canvasParams = new LinearLayout.LayoutParams(-1,0,1); canvasParams.setMargins(dp(10),dp(10),dp(10),dp(10)); root.addView(drawingView,canvasParams);
        pen.setOnClickListener(v -> drawingView.setErase(false)); erase.setOnClickListener(v -> drawingView.setErase(true)); clear.setOnClickListener(v -> drawingView.clear());
        addText.setOnClickListener(v -> showTextDialog()); addImage.setOnClickListener(v -> pickImage());

        LinearLayout bottom = new LinearLayout(this); bottom.setPadding(dp(10),dp(6),dp(10),dp(10)); bottom.setGravity(Gravity.CENTER); bottom.setBackgroundColor(Color.WHITE);
        Button plot=button("PLOT"), pause=button("PAUSE"), stop=button("STOP");
        bottom.addView(plot,new LinearLayout.LayoutParams(0,-2,2)); bottom.addView(pause,new LinearLayout.LayoutParams(0,-2,1)); bottom.addView(stop,new LinearLayout.LayoutParams(0,-2,1)); root.addView(bottom);

        LinearLayout jog = new LinearLayout(this);
        jog.setGravity(Gravity.CENTER);
        jog.setPadding(dp(8),dp(4),dp(8),dp(8));
        Button left=button("← 10"), up=button("↑ 10"), down=button("↓ 10"), right=button("10 →");
        Button penUp=button("PEN UP"), penDown=button("PEN DOWN");
        jog.addView(left,new LinearLayout.LayoutParams(0,-2,1));
        jog.addView(up,new LinearLayout.LayoutParams(0,-2,1));
        jog.addView(down,new LinearLayout.LayoutParams(0,-2,1));
        jog.addView(right,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(jog);
        LinearLayout penRow=new LinearLayout(this);
        penRow.setGravity(Gravity.CENTER);
        penRow.addView(penUp,new LinearLayout.LayoutParams(0,-2,1));
        penRow.addView(penDown,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(penRow);

        left.setOnClickListener(v -> jogMotors(-10,10));
        right.setOnClickListener(v -> jogMotors(10,-10));
        up.setOnClickListener(v -> jogMotors(10,10));
        down.setOnClickListener(v -> jogMotors(-10,-10));
        penUp.setOnClickListener(v -> setPen(false));
        penDown.setOnClickListener(v -> setPen(true));

        plot.setOnClickListener(v -> showPlotNotReady());
        pause.setOnClickListener(v -> toast("No active plot queue to pause."));
        stop.setOnClickListener(v -> emergencyStop());
        setContentView(root);
    }

    private void setStatus(String s, boolean connected) {
        if (usbStatus != null) { usbStatus.setText((connected ? "●  " : "○  ") + s); usbStatus.setTextColor(connected ? Color.rgb(22,120,72) : Color.rgb(65,75,90)); }
    }
    private void registerUsbReceiver() {
        IntentFilter f = new IntentFilter(); f.addAction(ACTION_USB_PERMISSION); f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED); f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        registerReceiver(usbReceiver, f);
        receiverRegistered = true;
    }
    private void scanUsbDevices() {
        if (usbManager == null) return;
        HashMap<String,UsbDevice> list = usbManager.getDeviceList();
        if (list == null || list.isEmpty()) { setStatus("No USB data device detected · check OTG and cable", false); return; }
        for (UsbDevice device : list.values()) {
            selectedDevice = device;
            setStatus("USB device found · VID " + device.getVendorId() + " · PID " + device.getProductId() + " · requesting permission", false);
            if (usbManager.hasPermission(device)) connectDevice(device); else {
                Intent intent = new Intent(ACTION_USB_PERMISSION);
                PendingIntent pi = PendingIntent.getBroadcast(this, 0, intent, Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT);
                usbManager.requestPermission(device, pi);
            }
            return;
        }
    }
    private void connectDevice(UsbDevice device) {
        closeConnection();
        usbConnection = usbManager.openDevice(device); selectedDevice = device;
        if (usbConnection == null) { setStatus("USB device found, but Android could not open it", false); return; }
        StringBuilder details = new StringBuilder("USB permission granted · VID ").append(device.getVendorId()).append(" · PID ").append(device.getProductId());
        int endpointCount = 0;
        for (int i=0;i<device.getInterfaceCount();i++) {
            UsbInterface intf=device.getInterface(i); endpointCount += intf.getEndpointCount();
        }
        details.append(" · ").append(device.getInterfaceCount()).append(" interface(s), ").append(endpointCount).append(" endpoint(s)");
        plotter = new EbbPlotter(device, usbConnection);
        if (!plotter.hasBulkPair()) {
            setStatus(details.toString() + " · no bulk USB endpoint pair", false);
            return;
        }
        boolean ebb = plotter.identify();
        if (ebb) setStatus(details.toString() + " · EBB firmware verified", true);
        else setStatus(details.toString() + " · USB open; EBB firmware not verified; motion locked", false);
    }
    private void closeConnection() { plotter=null; if (usbConnection != null) { usbConnection.close(); usbConnection=null; } selectedDevice=null; }
    // Experimental manual jog: bounded to 10 motor steps per tap.
    // This is available only after the controller identifies itself as EBB firmware.
    private void jogMotors(int motor1, int motor2) {
        if (plotter == null || !plotter.isVerified()) {
            toast("Motion locked: EBB firmware not verified.");
            return;
        }
        try {
            plotter.motors(true);
            plotter.moveSteps(motor1, motor2, 100);
            setStatus("EBB verified · sent small 10-step jog", true);
        } catch (Exception ex) {
            toast("Jog failed: " + ex.getMessage());
        }
    }

    private void setPen(boolean down) {
        if (plotter == null || !plotter.isVerified()) {
            toast("Pen control locked: EBB firmware not verified.");
            return;
        }
        try {
            plotter.pen(down);
            toast(down ? "Pen down command sent" : "Pen up command sent");
        } catch (Exception ex) {
            toast("Pen command failed: " + ex.getMessage());
        }
    }

    private void emergencyStop() {
        if (plotter != null && plotter.isVerified()) {
            try {
                plotter.pen(false);
                plotter.motors(false);
                toast("Stop sent: pen up, motors disabled.");
            } catch (Exception ex) {
                toast("Stop command failed: " + ex.getMessage());
            }
        } else {
            toast("No verified EBB session. Unplug USB to remove power.");
        }
    }

    private void showPlotNotReady() {
        new AlertDialog.Builder(this)
            .setTitle("Plot queue not ready")
            .setMessage("Manual jog and pen controls are available after EBB firmware verification. Automatic drawing-to-motor conversion and calibration are not implemented yet.")
            .setPositiveButton("OK", null).show();
    }

    private void showTextDialog() {
        EditText input = new EditText(this); input.setHint("Enter text");
        new AlertDialog.Builder(this).setTitle("Add text").setView(input).setPositiveButton("Add",(d,w)->drawingView.addLabel(input.getText().toString())).setNegativeButton("Cancel",null).show();
    }
    private void pickImage() { Intent i=new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*"); startActivityForResult(i,44); }
    @Override protected void onActivityResult(int req,int result,Intent data) { super.onActivityResult(req,result,data); if(req==44 && result==RESULT_OK && data!=null) toast("Image selected. Image-to-plot conversion is a next-stage feature."); }
    private void showProtocolNotice() { new AlertDialog.Builder(this).setTitle("Plotter protocol needed").setMessage("USB detection is implemented, but the MakerQ EasyDraw V3 command protocol has not yet been identified. No motion commands will be sent until the protocol is verified.").setPositiveButton("OK",null).show(); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    @Override protected void onDestroy() { closeConnection(); if(receiverRegistered) unregisterReceiver(usbReceiver); super.onDestroy(); }
}
