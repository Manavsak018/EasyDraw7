package com.manav.easydraw7;

import android.hardware.usb.*;
import java.nio.charset.StandardCharsets;

/** Guarded EBB/AxiDraw-compatible USB transport. Motion is enabled only after a V query identifies EBB firmware. */
public class EbbPlotter {
    private final UsbDeviceConnection connection;
    private final UsbEndpoint out, in;
    private final UsbInterface intf;
    private boolean verified = false;\n    private boolean experimentalMotionEnabled = true;
    private static final int TIMEOUT = 1200;

    public EbbPlotter(UsbDevice device, UsbDeviceConnection c) {
        connection=c; UsbEndpoint o=null, i=null; UsbInterface found=null;
        outer: for(int n=0;n<device.getInterfaceCount();n++) {
            UsbInterface candidate=device.getInterface(n);
            UsbEndpoint co=null, ci=null;
            for(int k=0;k<candidate.getEndpointCount();k++) {
                UsbEndpoint ep=candidate.getEndpoint(k);
                if(ep.getType()==UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if(ep.getDirection()==UsbConstants.USB_DIR_OUT) co=ep;
                    else ci=ep;
                }
            }
            if(co!=null && ci!=null) { found=candidate; o=co; i=ci; break outer; }
        }
        intf=found; out=o; in=i;
    }
    public boolean hasBulkPair(){ return intf!=null && out!=null && in!=null; }
    private synchronized String exchange(String command) {
        if(!hasBulkPair() || !connection.claimInterface(intf,true)) return "";
        try {
            byte[] bytes=(command+"\r").getBytes(StandardCharsets.US_ASCII);
            int sent=connection.bulkTransfer(out,bytes,bytes.length,TIMEOUT);
            if(sent<0) return "";
            byte[] reply=new byte[128]; int n=connection.bulkTransfer(in,reply,reply.length,TIMEOUT);
            return n>0 ? new String(reply,0,n,StandardCharsets.US_ASCII).trim() : "";
        } finally { connection.releaseInterface(intf); }
    }
    public boolean identify() {
        String v=exchange("V");
        verified=v.toUpperCase().contains("EBB") && v.toUpperCase().contains("FIRMWARE");
        return verified;
    }
    private void requireVerified(){
        if (!verified && !experimentalMotionEnabled)
            throw new IllegalStateException("EBB firmware not verified; motion blocked");
        if (!hasBulkPair())
            throw new IllegalStateException("No bulk USB data interface");
    }
    public boolean canAttemptExperimentalMotion(){ return experimentalMotionEnabled && hasBulkPair(); }
    public void motors(boolean on){ requireVerified(); exchange(on?"EM,1,1":"EM,0,0"); }
    public void pen(boolean down){ requireVerified(); exchange(down?"SP,0":"SP,1"); }
    /** Relative CoreXY step move. Caller must supply calibrated motor steps. */
    public void moveSteps(int motor1,int motor2,int durationMs){
        requireVerified(); int ms=Math.max(1,Math.min(60000,durationMs));
        exchange("SM,"+ms+","+motor1+","+motor2);
    }
    public boolean isVerified(){return verified;}
}
