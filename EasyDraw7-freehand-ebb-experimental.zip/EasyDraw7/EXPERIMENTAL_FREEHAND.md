# Experimental freehand / EBB mode

This build adds a freehand stroke queue, 1–100 mm jog-distance slider, 10–150 mm/s target-speed slider, editable motor steps/mm, and EBB-style bulk command streaming without requiring the `V` firmware-identification response.

**Unverified hardware mode:** VID/PID and a bulk endpoint pair do not prove EBB firmware compatibility. Commands `EM`, `SP`, and `SM` are sent as EBB-style ASCII commands and may be ignored or interpreted differently by other firmware. The app does not establish a physical emergency stop.

**Calibration and coordinate assumptions:** The initial steps/mm field is a placeholder (80), not a MakerQ factory calibration. Measure/calibrate it before expecting correct physical distances. Drawing maps the visible canvas to a 100 mm × 100 mm work area. Before plotting, manually position the pen carriage at the canvas origin (top-left of the intended work area); there is no homing/limit-switch implementation. Text and imported images are not converted into plot paths yet. The 10–150 mm/s slider controls the requested segment timing; it is not an acceleration setting. No acceleration ramp has been verified or implemented.

Use low speed and small jog distances for the first test. Keep clear of moving parts and disconnect USB power if motion is unexpected.
