package com.manav.easydraw7;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class DrawingView extends View {
    public static class Stroke { public final ArrayList<PointF> points = new ArrayList<>(); public boolean erased=false; }
    private static class RenderStroke { Path path; Paint paint; RenderStroke(Path p, Paint b){path=p;paint=b;} }
    private final ArrayList<Stroke> plotStrokes = new ArrayList<>();
    private final ArrayList<RenderStroke> renderStrokes = new ArrayList<>();
    private final Paint currentPaint = new Paint(3);
    private Path currentPath;
    private Stroke currentStroke;
    private boolean erase = false;
    private float lastX,lastY;
    public DrawingView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); currentPaint.setColor(Color.rgb(25,39,62)); currentPaint.setStyle(Paint.Style.STROKE); currentPaint.setStrokeWidth(4f); currentPaint.setStrokeCap(Paint.Cap.ROUND); currentPaint.setStrokeJoin(Paint.Join.ROUND); }
    public void setErase(boolean value) { erase=value; }
    public void clear() { plotStrokes.clear(); renderStrokes.clear(); invalidate(); }
    public List<Stroke> getPlotStrokes() { return new ArrayList<>(plotStrokes); }
    public void addLabel(String value) { if(value==null || value.trim().length()==0)return; Paint p=new Paint(3); p.setColor(Color.rgb(25,39,62)); p.setTextSize(32); Path path=new Path(); p.getTextPath(value,0,value.length(),24,Math.max(60,getHeight()/2),path); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); RenderStroke rs=new RenderStroke(path,p); renderStrokes.add(rs); Stroke s=new Stroke(); s.erased=true; plotStrokes.add(s); invalidate(); }
    @Override protected void onDraw(Canvas c) { super.onDraw(c); c.drawColor(Color.WHITE); Paint grid=new Paint(1); grid.setColor(Color.rgb(238,241,245)); grid.setStrokeWidth(1); for(int x=0;x<getWidth();x+=40)c.drawLine(x,0,x,getHeight(),grid); for(int y=0;y<getHeight();y+=40)c.drawLine(0,y,getWidth(),y,grid); for(RenderStroke s:renderStrokes)c.drawPath(s.path,s.paint); if(currentPath!=null)c.drawPath(currentPath,currentPaint); }
    @Override public boolean onTouchEvent(MotionEvent e) { float x=e.getX(),y=e.getY(); switch(e.getAction()){case MotionEvent.ACTION_DOWN: currentPath=new Path(); currentStroke=new Stroke(); currentStroke.erased=erase; currentPath.moveTo(x,y); currentStroke.points.add(new PointF(x,y)); lastX=x;lastY=y; invalidate();return true; case MotionEvent.ACTION_MOVE: if(currentPath!=null){currentPath.quadTo(lastX,lastY,(x+lastX)/2,(y+lastY)/2); if(currentStroke.points.isEmpty() || Math.hypot(x-lastX,y-lastY)>3) currentStroke.points.add(new PointF(x,y)); lastX=x;lastY=y;invalidate();}return true; case MotionEvent.ACTION_UP: if(currentPath!=null){Paint p=new Paint(currentPaint); if(erase){p.setColor(Color.WHITE);p.setStrokeWidth(22f);} renderStrokes.add(new RenderStroke(currentPath,p)); if(currentStroke!=null && !currentStroke.erased && currentStroke.points.size()>1)plotStrokes.add(currentStroke); currentPath=null;currentStroke=null;invalidate();}return true;} return true; }
}
