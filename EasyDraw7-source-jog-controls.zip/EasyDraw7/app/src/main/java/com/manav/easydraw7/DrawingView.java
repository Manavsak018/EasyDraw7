package com.manav.easydraw7;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;

public class DrawingView extends View {
    private static class Stroke { Path path; Paint paint; Stroke(Path p, Paint b){path=p;paint=b;} }
    private final ArrayList<Stroke> strokes = new ArrayList<>();
    private final Paint background = new Paint(3);
    private final Paint currentPaint = new Paint(3);
    private Path currentPath;
    private boolean erase = false;
    private float lastX,lastY;
    public DrawingView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); currentPaint.setColor(Color.rgb(25,39,62)); currentPaint.setStyle(Paint.Style.STROKE); currentPaint.setStrokeWidth(4f); currentPaint.setStrokeCap(Paint.Cap.ROUND); currentPaint.setStrokeJoin(Paint.Join.ROUND); }
    public void setErase(boolean value) { erase=value; }
    public void clear() { strokes.clear(); invalidate(); }
    public void addLabel(String value) { if(value==null || value.trim().length()==0)return; Paint p=new Paint(3); p.setColor(Color.rgb(25,39,62)); p.setTextSize(32); Path path=new Path(); p.getTextPath(value,0,value.length(),24,Math.max(60,getHeight()/2),path); p.setStyle(Paint.Style.FILL); strokes.add(new Stroke(path,p)); invalidate(); }
    @Override protected void onDraw(Canvas c) { super.onDraw(c); c.drawColor(Color.WHITE); Paint grid=new Paint(1); grid.setColor(Color.rgb(238,241,245)); grid.setStrokeWidth(1); for(int x=0;x<getWidth();x+=40)c.drawLine(x,0,x,getHeight(),grid); for(int y=0;y<getHeight();y+=40)c.drawLine(0,y,getWidth(),y,grid); for(Stroke s:strokes)c.drawPath(s.path,s.paint); if(currentPath!=null)c.drawPath(currentPath,currentPaint); }
    @Override public boolean onTouchEvent(MotionEvent e) { float x=e.getX(),y=e.getY(); switch(e.getAction()){case MotionEvent.ACTION_DOWN: currentPath=new Path(); currentPath.moveTo(x,y); lastX=x;lastY=y; invalidate();return true; case MotionEvent.ACTION_MOVE: if(currentPath!=null){currentPath.quadTo(lastX,lastY,(x+lastX)/2,(y+lastY)/2);lastX=x;lastY=y;invalidate();}return true; case MotionEvent.ACTION_UP: if(currentPath!=null){Paint p=new Paint(currentPaint); if(erase){p.setColor(Color.WHITE);p.setStrokeWidth(22f);} strokes.add(new Stroke(currentPath,p));currentPath=null;invalidate();}return true;} return true; }
}
