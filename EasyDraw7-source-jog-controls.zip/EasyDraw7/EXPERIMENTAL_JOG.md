# Experimental manual controls

Added four 10-step manual jog buttons (two diagonal motor combinations), PEN UP, PEN DOWN, and STOP.
Controls are enabled only when the existing `V` query identifies EBB firmware. This is intentionally not an unconditional unlock.
The exact MakerQ motor mapping, physical axis direction, step calibration and travel limits remain unverified.
Keep the pen lifted and machine clear for initial testing. A 10-step command is a small bounded command, but physical displacement depends on machine mechanics and firmware configuration.
Automatic drawing-to-motor plotting is not implemented; PLOT remains a clear not-ready notice.
If the controller is not identified, use unplugging USB to remove motor power; software stop cannot be guaranteed.
