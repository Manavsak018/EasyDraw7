# EasyDraw 7 USB protocol status

MakerQ describes the EasyDraw V3 EasyDrawMini board as a USB dual-stepper controller, and its V3 product page says the machine runs the AxiDraw Inkscape extension. The source therefore includes a guarded EBB/AxiDraw-compatible transport probe.

`EbbPlotter` sends only the read-only `V\r` firmware-identification query initially. Motion functions refuse to run unless the reply identifies EBB firmware. This is intentional: USB enumeration alone is not proof that the board speaks EBB commands.

Important limitations in this build:
- No verified V3 reply has yet been captured from this particular plotter.
- The freehand canvas is not yet converted into a calibrated CoreXY movement queue.
- Steps/mm, motor direction, pen servo settings, and physical page dimensions must be calibrated before plotting.
- PLOT remains disabled. Do not bypass the firmware check or send guessed movement commands.

References:
- MakerQ EasyDraw V3: https://www.makerq.com/products/easydraw-v3-writing-and-drawing-machine-fully-assembled
- MakerQ EasyDraw control board: https://www.makerq.com/products/easydraw-control-board
- AxiDraw EBB USB API: https://axidraw.com/doc/py_api/
