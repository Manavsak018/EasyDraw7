# EasyDraw 7 — Android 7.1.1 starter project

This is a fresh native Android Java project targeting API 25 (Android 7.1.1), with compile SDK 28 and target SDK 28.

## Included in this first prototype
- USB host feature declaration and USB device enumeration via `UsbManager`.
- Runtime USB permission request and attach/detach monitoring.
- Shows USB vendor ID, product ID, interface count and endpoint count after permission is granted.
- Basic touch drawing canvas, erase and clear tools, text entry, image picker entry point.
- Plot/Pause/Stop controls are visibly present but intentionally do not send motion commands.

## Important limitations
- The MakerQ EasyDraw V3 USB command protocol has not been identified. USB power alone is not proof of data communication. This prototype will not move the plotter or send guessed commands.
- Image-to-plot conversion, SVG/font rendering, voice input, example templates and real plot/pause/stop are not implemented yet.
- This is source code, not a compiled APK. Use the included GitHub Actions workflow to build a debug APK in the cloud.
- The uploaded original APK was used as a feature reference; its compiled code, branding assets and licensing/protection code were not copied or bypassed.

## Build APK with GitHub Actions (no PC required)
1. Create a GitHub account or sign in at https://github.com.
2. Create a **new public or private repository** named `EasyDraw7`.
3. Upload the contents of this project folder to the repository's `main` branch. Make sure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab and select **Build EasyDraw 7 APK**.
5. Tap **Run workflow** and wait for the run to finish successfully.
6. Open the completed run, scroll to **Artifacts**, and download `EasyDraw7-debug-apk`.
7. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Transfer that APK to the OPPO A83 and install it.

The workflow uses Java 17 for Android SDK setup, Java 8 for the legacy Gradle build, Gradle 5.4.1, Android Gradle Plugin 3.5.4, Android SDK 28 and Build Tools 28.0.3. Java 8 source/target compatibility is enabled for the app.
