# Unverified experimental motion mode

This build permits experimental manual jog and pen commands when a USB bulk IN/OUT pair is present, without requiring a successful EBB firmware query.

- EBB firmware status remains truthful: the app does NOT display VERIFIED unless the firmware query passes.
- Manual jog remains limited to 10 motor steps per button press and 100 ms move duration.
- The first jog/pen command displays a confirmation warning.
- Commands are still EBB-style ASCII commands; MakerQ firmware compatibility and motor mapping are unverified.
- Automatic drawing plotting is not implemented.
- If movement is unexpected, disconnect OTG/USB immediately. Software STOP is not guaranteed on an incompatible controller.
